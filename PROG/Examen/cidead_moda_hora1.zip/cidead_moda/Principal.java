/*
 * Clase principal del programa
 */
package cidead_moda;

import java.util.*;

/**
 *
 * @author Francisco Alacreu
 */
public class Principal {

    static Scanner teclado = new Scanner(System.in);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int seleccion=menu();
        
    }
    
    
    static int menu(){
        System.out.println("-------------------------------------------");
        System.out.println("GESTIÓN DE COMPRA DE ARTICULOS: CIDEAD MODA");
        System.out.println("-------------------------------------------");
        System.out.println("1. Nuevo Artículo");
        System.out.println("2. Listar Artículos");
        System.out.println("3. Buscar un Artículo");
        System.out.println("4. Modificar Datos de un Artículo");
        System.out.println("5. Eliminar un Artículo");
        System.out.println("6. Salir");
        System.out.println("-------------------------------------------");
        System.out.println("Elige una opción: \n");
        
        int sel = teclado.nextInt();
        teclado.nextLine();             //consumimos el salto de linea
        
        if(sel>6 || sel < 1){
            return -1;                  //si la opcion no es correcta devuelve -1
        }else{
            return sel;
        }
    }
    
}
