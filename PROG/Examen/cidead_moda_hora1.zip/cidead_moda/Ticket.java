/*
 * Clase ticket para la gestion de articulos
 */

package cidead_moda;

import java.util.ArrayList;

/**
 * 
 * @author Francisco Alacreu
 */
public class Ticket {
   
    ArrayList<Articulo> ticketCompra=new ArrayList<Articulo>();
    
    /**
     * metodo para la busqueda de articulos
     * @param codigo codigo del articulo a buscar
     * @return cadena con los datos del articulo encontrado o error si no se encuentra
     */
    public String buscarArticulo(int codigo){
        
        return "";
    }
    /**
     * Metodo para la insercion de nuevos articulos en el ticket
     * @param codigo
     * @param descripcion
     * @param genero
     * @param talla
     * @param composicion
     * @param precio 
     */
    public void insertarArticulo(int codigo, String descripcion, String genero, String talla, String composicion, double precio){
        ticketCompra.add(new Articulo(codigo, descripcion, genero, talla, composicion, precio));                //introducimos los datos del nuevo articulo
    }
    
    
    /**
     * Metodo para mostrar el listado de articulos ordenados por codigo
     * @return Listado de articulo
     */
    public String mostrarListaArticulos(){
        return "";
    }
    
    /**
     * Metodo para actualizar articulos con los datos que se pasan como parametros
     * @param codigo
     * @param descripcion
     * @param genero
     * @param talla
     * @param composicion
     * @param precio
     */
    public void actualizarUnArticulo(int codigo, String descripcion, String genero, String talla, String composicion, double precio){
        
    }
    
    /**
     * Metodo para eliminar articulos
     * @param codigo codigo del articulo a eliminar 
     */
    public void eliminarUnArticulo(int codigo){
        
    }
}





